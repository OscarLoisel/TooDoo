package com.example.connexion;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddToDo extends AppCompatActivity {

    private EditText addname, adddescription, adddate;
    private Button addbtn;
    private FirebaseDatabase firebaseDatabase;
    private FirebaseAuth firebaseAuth;
    String name, description, date;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_to_do);

        addname = findViewById(R.id.etAddNom);
        adddescription = findViewById(R.id.etAddDesc);
        adddate = findViewById(R.id.etAddDate);
        addbtn = findViewById(R.id.btnAddSave);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();

        final DatabaseReference ref3 = firebaseDatabase.getReference(firebaseAuth.getUid());

        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (addtodo()) {
                    String name = addname.getText().toString();
                    String description = adddescription.getText().toString();
                    String date = adddate.getText().toString();

                    UserTodo userTodo = new UserTodo(name, description, date);
                    ref3.setValue(userTodo);

                    //ref3.child("Name").setValue(name);
                    //ref3.child("Description").setValue(description);
                    //ref3.child("Date").setValue(date);

                    finish();
                }
            }

            private Boolean addtodo() {
                Boolean result = false;

                name = addname.getText().toString();
                description = adddescription.getText().toString();
                date = adddate.getText().toString();

                if (name.isEmpty() || description.isEmpty() || date.isEmpty()) {
                    Toast.makeText(AddToDo.this, "Veuillez rentrer toutes les informations", Toast.LENGTH_SHORT).show();
                } else {
                    sendNewTodo();
                    Toast.makeText(AddToDo.this, "Todo enregistrée", Toast.LENGTH_SHORT).show();
                    result = true;
                }
                return result;
            }
        });
    }



    private void sendNewTodo() {
                FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
                DatabaseReference Ref2 = firebaseDatabase.getReference(firebaseAuth.getUid());
                UserTodo userTodo = new UserTodo(name, description, date);
                Ref2.setValue(userTodo);
                //Ref2.child("Name").setValue(name);
                //Ref2.child("Description").setValue(description);
                //Ref2.child("Date").setValue(date);

            }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case android.R.id.home:
                onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
}