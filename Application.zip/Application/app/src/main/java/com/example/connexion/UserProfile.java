package com.example.connexion;

public class UserProfile {
    public String userFirstName;
    public String userLastName;
    public String userEmail;

    public UserProfile(){

    }

    //definition du concepter, qui va lancer la fonction dès qu'un element est ajouté
    public UserProfile(String userEmail, String userFirstName, String userLastName){
        this.userFirstName = userFirstName;
        this.userLastName = userLastName;
        this.userEmail = userEmail;
    }

    public String getUserFirstName() {
        return userFirstName;
    }

    public void setUserFirstName(String userFirstName) {
        this.userFirstName = userFirstName;
    }

    public String getUserLastName() {
        return userLastName;
    }

    public void setUserLastName(String userLastName) {
        this.userLastName = userLastName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
}
