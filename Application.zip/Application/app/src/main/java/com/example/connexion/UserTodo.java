package com.example.connexion;

public class UserTodo {
    public String todoName;
    public String todoDesc;
    public String todoDate;

    public UserTodo(){

    }

    //definition du concepter, qui va lancer la fonction dès qu'un element est ajouté
    public UserTodo(String todoName, String todoDesc, String todoDate){
        this.todoName = todoName;
        this.todoDesc = todoDesc;
        this.todoDate = todoDate;
    }

    public String getTodoName() {
        return todoName;
    }

    public void setTodoName(String todoName) {
        this.todoName = todoName;
    }

    public String getTodoDesc() {
        return todoDesc;
    }

    public void setTodoDesc(String todoDesc) {
        this.todoDesc = todoDesc;
    }

    public String getTodoDate() {
        return todoDate;
    }

    public void setTodoDate(String todoDate) {
        this.todoDate = todoDate;
    }
}
