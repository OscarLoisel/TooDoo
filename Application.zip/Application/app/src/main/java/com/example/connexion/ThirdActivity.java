package com.example.connexion;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ThirdActivity extends AppCompatActivity {

    private Button RegBtn;
    private EditText NewEmail, NewPassword, NewLastName, NewFirstName;
    private TextView GoToLogin;
    private FirebaseAuth firebaseAuth;
    String email, firstname, lastname, password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        RegBtn = findViewById(R.id.btnRegister);
        NewEmail = findViewById(R.id.etNewEmail);
        NewPassword = findViewById(R.id.etNewPassword);
        NewLastName = findViewById(R.id.etNewLastName);
        NewFirstName = findViewById(R.id.etNewFirstName);
        GoToLogin = findViewById(R.id.GoToLogin);
        firebaseAuth = FirebaseAuth.getInstance();


        RegBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (registration()){
            //Upload data to the database
                    String user_email = NewEmail.getText().toString().trim();
                    String user_password = NewPassword.getText().toString().trim();

                    firebaseAuth.createUserWithEmailAndPassword(user_email, user_password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()){
                                senEmailVerification();
                                sendUserData();
                                Toast.makeText(ThirdActivity.this, "Inscription et chargement terminés", Toast.LENGTH_SHORT).show();
                                finish();
                                startActivity(new Intent(ThirdActivity.this, MainActivity.class));
                            }else{
                                Toast.makeText(ThirdActivity.this, "Aïe, un problème est survenu", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                };
            }
        });

        GoToLogin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ThirdActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
    private Boolean registration (){
        Boolean result = false;

        lastname = NewLastName.getText().toString();
        firstname = NewFirstName.getText().toString();
        password = NewPassword.getText().toString();
        email = NewEmail.getText().toString();

        if (lastname.isEmpty() ||firstname.isEmpty() || password.isEmpty() || email.isEmpty()){
            Toast.makeText(this,"Veuillez rentrer toutes les informations", Toast.LENGTH_SHORT).show();
        } else{
            result = true;
        }
        return result;
    }

    private void senEmailVerification(){
        FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();
        if(firebaseUser != null){
            firebaseUser.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()){
                        sendUserData();
                        Toast.makeText(ThirdActivity.this, "Inscription terminée, email de verification envoyé", Toast.LENGTH_SHORT).show();
                        firebaseAuth.signOut();
                        finish();
                        startActivity(new Intent(ThirdActivity.this, MainActivity.class));
                    }else{
                        Toast.makeText(ThirdActivity.this, "L'email de verification n'a pas été envoyé", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    private void sendUserData(){
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        DatabaseReference myRef = firebaseDatabase.getReference(firebaseAuth.getUid());
        UserProfile userProfile = new UserProfile(lastname, firstname, email);
        myRef.setValue(userProfile);
    }
}